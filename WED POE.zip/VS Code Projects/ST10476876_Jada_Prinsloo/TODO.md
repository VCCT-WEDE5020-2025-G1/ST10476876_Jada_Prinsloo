In breads.html:
1. find images for all breads
2. update src="src/img/whatever_bread.jpg"

In cookies.html:
1. find images for shortbread, snickerdoodle
2. update src="src/img/cookie_name.jpg"

Fix nav bar on all pages so they are identical
Make sure nav css classes are the same everywhere.

in special occasiona cakes
1. Find birthday cake photo and update reference

Find a hero banner

Add references to readme
1. Limnos
2. W3schools