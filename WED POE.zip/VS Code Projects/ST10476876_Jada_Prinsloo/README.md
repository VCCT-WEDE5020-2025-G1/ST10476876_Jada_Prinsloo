# ST10476876_Jada_Prinsloo

## Intro to Limnos
My website is a revamped version of the Limno's bakery website. Limnos is a South African bakery (Limnos Bakers, 2025)
## How to run the site

## Changelog  
POE Part 1:
- 
- 

POE Part 1 Updates:
- 
- 

POE Part 2:
- 
- 

POE Part 2 Updates:
- 
- 


## Screenshots

### Site Map
<img width="844" height="614" alt="image" src="https://github.com/user-attachments/assets/b0a7561f-e1a2-49d0-9b1f-d197fe1638e9" />

### Website Screenshot
<img width="940" height="742" alt="image" src="https://github.com/user-attachments/assets/6924b9ec-0f65-4068-84f0-00171b7269ef" />

Home page for website to go from one page to the other 

### CSS Example
<img width="726" height="659" alt="Screenshot 2025-09-29 162310" src="https://github.com/user-attachments/assets/c2cef5b5-710c-4167-a42d-c14ceed82bee" />

The css for this website is fairly simple. I used W3schools to understand how to apply CSS rules (W3Schools, 2025)


# Reference List

Limnos Bakers, 2025. Limnos Bakers. [online] Available at: <https://limnosbakers.co.za/> [Accessed 14 October 2025].  

W3Schools, 2025. CSS Tutorial. [online] Available at: <https://www.w3schools.com/css/> [Accessed 14 October 2025].
